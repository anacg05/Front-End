import ravena from './assets/ravena.jpg';

function Imagem() {
    return (
        <figure>
            <img
                src={ravena} alt="Ravena"
            />
        </figure>
    );
}

export default Imagem;